/**
 * ShopReactNative
 *
 * @author Tony Wong
 * @date 2016-08-13
 * @email 908601756@qq.com
 * @copyright Copyright © 2016 EleTeam
 * @license The MIT License (MIT)
 */

'use strict';
// @property (nonatomic, copy) NSNumber *id;
// @property (nonatomic, copy) NSString *username;// 用户名
// @property (nonatomic, copy) NSString *email;	// 邮箱
// @property (nonatomic, copy) NSString *mobile;	// 手机
// @property (nonatomic, copy) NSNumber *level;
// @property (nonatomic, copy) NSString *level_label;
// @property (nonatomic, copy) NSNumber *created_at;
// @property (nonatomic, copy) NSNumber *updated_at;
// @property (nonatomic, copy) NSString *access_token;