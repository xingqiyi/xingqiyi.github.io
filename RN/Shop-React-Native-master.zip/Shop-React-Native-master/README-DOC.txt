# 该项目的短链接:
    发布一个电商APP开源项目 Shop-React-Native, 一次开发同时运行在iOS和Android上, 极大地提高开发速度和降低人力成本。
    代码托管在: http://t.cn/Rc4mP0l

# 参考开源项目
    https://github.com/ljunb/react-native-iShiWuPai //初始化项目+redux
    react-native-redux-demo //redux登录demo
    demoJD
    https://github.com/jiangqqlmj/GaGaMall 点餐商城
    https://github.com/JasonStu/ReactNative_Shopping 实现电商基础界面和购物车功能

# 安卓的问题
    1.启动安卓AVD虚拟模拟器
        $android avd
    2.选中Emulator, 点击start, 就能启动Emulator
    3. $react-native run-android
    4.查看对应的安卓设备
        $ adb devices
    新建安卓AVD虚拟模拟器
        http://jingyan.baidu.com/article/a681b0ded7e7573b1943465b.html

# 需要更改原生文件的组件
     react-native-vector-icons   https://www.npmjs.com/package/react-native-vector-icons