import App from './js/App';
export default App;
