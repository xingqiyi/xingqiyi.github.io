### Version
Tell us which versions you are using: 

- react-native-router-flux v4.?.? (v3 is not supported)
- react-native v0.?.?

### Expected behaviour



### Actual behaviour



### Steps to reproduce
For non-obvious bugs, please fork this component, modify Example project to reproduce your issue and include link here.
1.
2.
3.

<!-- Love react-native-router-flux? Please consider supporting our collective:
👉  https://opencollective.com/react-native-router-flux/donate -->
