import React from 'react';
import { DatePicker } from 'antd';

const App = () => (
  <div style={{ margin: 100 }}>
    <h1>AntDesign Demo</h1>
    <hr /><br />
    <DatePicker />
  </div>
);

export default App;
