import React from 'react';
import ReactDOM from 'react-dom';
import MobileDemo from './src/mobile/';

ReactDOM.render(<MobileDemo />, document.getElementById('root'));
