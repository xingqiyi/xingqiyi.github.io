> antd 和 antd-mobile 混合项目 (pc & mobile)， 以 ant-tool 介绍

### 调试

- pc: `npm start` (http://127.0.0.1:8989/index.html)
- mobile: `npm run start:mobile` (http://127.0.0.1:8989/mobile.html)

### 编译

- pc: `npm run build`
- mobile: `npm run build:mobile`
