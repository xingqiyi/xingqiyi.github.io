# antd-mobile Web Q & A demo

> some questions and answers

use [react-router@3](https://github.com/ReactTraining/react-router/blob/v3/docs/Introduction.md)
