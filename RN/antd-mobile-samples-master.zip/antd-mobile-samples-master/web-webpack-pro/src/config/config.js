export const GLOBAL_API_DOMAIN = 'https://xgj-server.herokuapp.com/api'
export const CLIENT_INDEXEDDB_NAME = 'xgj'
