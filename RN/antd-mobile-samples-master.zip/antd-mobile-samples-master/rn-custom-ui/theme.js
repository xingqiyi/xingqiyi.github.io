module.exports = {
  brand_primary: 'red',
  color_link: 'red',
  border_color_base: 'green',
};
