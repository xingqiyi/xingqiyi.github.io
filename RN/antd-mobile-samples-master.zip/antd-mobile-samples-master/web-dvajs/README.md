
## dva + TypeScript + atool-build

### dev
- Run `npm install`
- `npm start`
- [http://localhost:8989](http://localhost:8989)

### build

    npm run build
