import { Menu } from 'antd-mobile';
import React from 'react';
export default class MenuExample extends React.Component {
    render() {
        return (<Menu />);
    }
}
