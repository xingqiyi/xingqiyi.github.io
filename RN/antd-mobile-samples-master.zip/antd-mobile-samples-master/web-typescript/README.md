
## antd-mobile + TypeScript

> [TypeScript-react](https://www.typescriptlang.org/docs/handbook/react-&-webpack.html)
官方教程里提供的 [awesome-typescript-loader](https://www.npmjs.com/package/awesome-typescript-loader)
建议不要使用，建议改用 [ts-loader](https://www.npmjs.com/package/ts-loader)
>
> 参考示例 https://github.com/Microsoft/TypeScriptSamples/blob/master/react-flux-babel-karma/webpack.config.js

### Install & Start

```shell
npm i
npm start
```

open http://localhost:8000/

### Build

```
npm run build
```
