## antd-mobile demo with roadhog, dva

Include below common usage:

- custom svg config
- rem config
- custom theme config

### dev

```
npm install
npm start
```

http://localhost:8000/

