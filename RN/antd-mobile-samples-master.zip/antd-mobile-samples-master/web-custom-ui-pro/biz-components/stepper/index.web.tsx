import Stepper from 'antd-mobile/lib/stepper/index.web';

export default Stepper;
