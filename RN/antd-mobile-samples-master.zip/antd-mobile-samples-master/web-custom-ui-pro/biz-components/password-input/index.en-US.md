---
category: Components
type: Biz
chinese: PasswordInput
english: PasswordInput
---


## API

### PasswordInput

| 成员        | 说明    | 类型      | 默认值       |
|------------|---------|---------|--------------|
|       |        |      String         |  |

