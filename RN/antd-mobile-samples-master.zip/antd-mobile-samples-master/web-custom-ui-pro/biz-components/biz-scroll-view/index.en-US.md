---
category: Components
type: Biz
chinese: 滚动视图
english: ScrollView
---


滚动视图


## API  

| 成员        | 说明           | 类型      | 默认值       |
|------------|----------------|--------------------|--------------|
|        |    |  |  |
