if (typeof console !== 'undefined' && console.error) {
  console.error(`Note: must use https://github.com/ant-design/babel-plugin-import .
For more information, please see https://github.com/ant-design/ant-design-mobile/issues/602 `);
}
export default {};
