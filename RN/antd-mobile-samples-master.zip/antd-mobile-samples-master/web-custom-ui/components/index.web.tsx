// for TypeScript's `.d.ts`

export { default as Button } from './button/index.web';
export { default as Icon } from './icon/index.web';
