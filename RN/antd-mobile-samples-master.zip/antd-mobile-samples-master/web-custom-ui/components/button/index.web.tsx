import Button from 'antd-mobile/lib/button/index.web';

export default Button;
