---
category: Basic Components
type: Basic Components
chinese: 图标
english: Icon
---

图标。

## 如何使用

使用 `<Icon />` 标签声明组件，指定图标对应的 type 属性，示例代码如下:

```html
<Icon type="link" size="lg" />
```
