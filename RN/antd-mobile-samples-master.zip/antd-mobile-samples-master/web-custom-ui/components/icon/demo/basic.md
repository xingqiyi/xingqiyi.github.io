---
order: 1
title: 大小
---

````jsx
import { Icon } from 'antd_mobile_custom_ui_exa';

ReactDOM.render(<div>
  <Icon type="check" size="xxs" />
</div>, mountNode);
````
