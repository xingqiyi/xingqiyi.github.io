import Radio from './Radio';
import RadioItem from './RadioItem';

Radio.RadioItem = RadioItem;

export default Radio;
