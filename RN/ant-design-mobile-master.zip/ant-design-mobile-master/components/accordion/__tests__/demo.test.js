import { webDemoTest } from '../../../tests/shared/demoTest';

webDemoTest('accordion');
