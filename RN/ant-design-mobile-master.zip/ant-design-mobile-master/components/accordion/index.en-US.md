---
category: Components
type: Data Display
title: Accordion
---

You can collapse / expand the content area.

### Rules
- Group and hide complex areas.
- Typically, only a single content area is allowed to expand at a time; in special cases, multiple content areas can be expanded at the same time.


## API

### Accordion

Support WEB, React-Native.

Properties | Descrition | Type | Default
-----------|------------|------|--------
| activeKey | current active Panel key | Array or String   | The first panel key on accordion mode|
| defaultActiveKey | default active key | String   | null |
| accordion (`web only`) | accordion mode | Boolean | false  |
| onChange    | called when collapse Panel is changed | (key: string): void |  noop  |
| openAnimation (`web only`)  |  set the custom switch animation, disable the animation can be set to `{}` | Object | ref `rc-collapse/lib/openAnimationFactory.js` |

### Accordion.Panel

Support WEB.

Properties | Descrition | Type | Default
-----------|------------|------|--------
| key  | corresponding activeKey   | String   | -   |
| header | header content of Panel | React.Element or String | -   |

Note: RN Accordion Depends on the Icon component, and need to add the corresponding iconfont; currently do not support nested use.
