import { rnDemoTest } from '../../../tests/shared/demoTest';

rnDemoTest('checkbox');
