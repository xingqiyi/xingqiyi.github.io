import Checkbox from './Checkbox';
import AgreeItem from './AgreeItem';
import CheckboxItem from './CheckboxItem';

Checkbox.AgreeItem = AgreeItem;
Checkbox.CheckboxItem = CheckboxItem;

export default Checkbox;
