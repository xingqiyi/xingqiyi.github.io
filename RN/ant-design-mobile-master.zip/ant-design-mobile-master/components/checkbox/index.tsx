import Checkbox from './Checkbox';
import CheckboxItem from './CheckboxItem';
import AgreeItem from './AgreeItem';

Checkbox.CheckboxItem = CheckboxItem;
Checkbox.AgreeItem = AgreeItem;

export default Checkbox;
