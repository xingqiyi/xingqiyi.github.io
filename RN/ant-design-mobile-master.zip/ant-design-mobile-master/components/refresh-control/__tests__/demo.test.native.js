import { rnDemoTest } from '../../../tests/shared/demoTest';

rnDemoTest('refresh-control');
