import React from 'react';
import RangeProps from './PropsType';

export default class Range extends React.Component<RangeProps, any> {
  componentDidMount() {
    console.warn('TODO for react-native');
  }

  render() {
    return null;
  }
}
