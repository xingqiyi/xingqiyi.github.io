import LocaleProvider from './locale-provider';

export default LocaleProvider;
