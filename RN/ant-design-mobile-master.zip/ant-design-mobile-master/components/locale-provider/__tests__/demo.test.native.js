import { rnDemoTest } from '../../../tests/shared/demoTest';

rnDemoTest('locale-provider');
