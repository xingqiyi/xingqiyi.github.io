import { rnDemoTest } from '../../../tests/shared/demoTest';

rnDemoTest('image-picker');
