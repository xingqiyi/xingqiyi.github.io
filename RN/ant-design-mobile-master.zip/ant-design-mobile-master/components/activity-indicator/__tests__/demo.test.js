import { webDemoTest } from '../../../tests/shared/demoTest';

webDemoTest('activity-indicator');
