import { rnDemoTest } from '../../../tests/shared/demoTest';

rnDemoTest('activity-indicator');
