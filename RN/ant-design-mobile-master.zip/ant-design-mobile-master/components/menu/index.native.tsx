import React from 'react';
import { MenuProps } from './PropsType';

export default class Menu extends React.Component<MenuProps, any> {
  componentDidMount() {
    console.warn('TODO for react-native');
  }

  render() {
    return null;
  }
}
