import DatePickerLocale from 'rmc-date-picker/lib/locale/en_US';

export default DatePickerLocale;
