import DatePickerLocale from 'rmc-date-picker/lib/locale/zh_CN';

export default DatePickerLocale;
