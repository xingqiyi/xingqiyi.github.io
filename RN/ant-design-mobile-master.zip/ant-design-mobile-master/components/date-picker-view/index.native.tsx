import DatePickerView from './date-picker-view';

export default DatePickerView;
