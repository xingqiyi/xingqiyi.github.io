export default {
  confirmLabel: '确定',
};
