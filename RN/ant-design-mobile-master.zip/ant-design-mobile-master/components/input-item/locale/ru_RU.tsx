export default {
  confirmLabel: 'сделанный',
};
