export default {
  confirmLabel: 'Done',
};
