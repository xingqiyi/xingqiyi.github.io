import { webDemoTest } from '../../../tests/shared/demoTest';

webDemoTest('input-item');
