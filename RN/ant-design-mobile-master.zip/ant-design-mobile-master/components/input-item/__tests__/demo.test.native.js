import { rnDemoTest } from '../../../tests/shared/demoTest';

rnDemoTest('input-item');
