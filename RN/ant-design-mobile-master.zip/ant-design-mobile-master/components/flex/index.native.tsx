import Flex from './Flex';
import FlexItem from './FlexItem';

Flex.Item = FlexItem;

export default Flex;
