import { rnDemoTest } from '../../../tests/shared/demoTest';

rnDemoTest('drawer', { skip: ['basic'] });
