import { rnDemoTest } from '../../../tests/shared/demoTest';

rnDemoTest('badge');
