import createSliderWithTooltip from 'rc-slider/lib/createSliderWithTooltip';

export default createSliderWithTooltip;
