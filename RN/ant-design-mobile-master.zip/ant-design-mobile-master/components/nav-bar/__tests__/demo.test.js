import { webDemoTest } from '../../../tests/shared/demoTest';

webDemoTest('nav-bar');
