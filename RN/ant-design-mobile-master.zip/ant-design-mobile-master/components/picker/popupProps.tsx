export default {
  WrapComponent: 'div',
  transitionName: 'am-slide-up',
  maskTransitionName: 'am-fade',
};
