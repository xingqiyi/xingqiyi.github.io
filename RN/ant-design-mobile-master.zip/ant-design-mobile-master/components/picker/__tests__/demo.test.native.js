import { rnDemoTest } from '../../../tests/shared/demoTest';

rnDemoTest('picker');
