import { webDemoTest } from '../../../tests/shared/demoTest';

webDemoTest('list-view');
