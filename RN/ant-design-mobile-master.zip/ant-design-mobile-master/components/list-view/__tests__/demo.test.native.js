import { rnDemoTest } from '../../../tests/shared/demoTest';

rnDemoTest('list-view');
