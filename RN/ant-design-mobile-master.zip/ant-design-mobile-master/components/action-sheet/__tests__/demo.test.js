import { webDemoTest } from '../../../tests/shared/demoTest';

webDemoTest('action-sheet');
