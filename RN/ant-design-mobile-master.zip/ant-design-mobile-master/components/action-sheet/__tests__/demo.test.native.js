import { rnDemoTest } from '../../../tests/shared/demoTest';

rnDemoTest('action-sheet');
