# 搜索热门推荐

* POST `/capi.php`
* c `54`

## v2.0 添加

## 请求参数

## 返回参数

## 返回实例

```JSON
{
  "status": 1,
  "info": "",
   "list": [
		{
			"id": "2",
			"name": "模板网吧",
			"barcode": "42010400005",
			"hot_level": "1"
		},
		{
			"id": "7",
			"name": "5账号网吧",
			"barcode": "42010200002",
			"hot_level": "1"
		},
		{
			"id": "9",
			"name": "3账号网吧",
			"barcode": "42010200011",
			"hot_level": "1"
		},
		{
			"id": "10",
			"name": "1账号网吧",
			"barcode": "42010200010",
			"hot_level": "1"
		},
		{
			"id": "11",
			"name": "2账号网吧",
			"barcode": "42010214733",
			"hot_level": "1"
		},
		{
			"id": "89",
			"name": "测试数据6",
			"barcode": "11010100020",
			"hot_level": "2"
		},
		{
			"id": "75",
			"name": "ghjhgjghjghj",
			"barcode": "11010100007",
			"hot_level": "2"
		},
		{
			"id": "44",
			"name": "连锁网吧0301-2",
			"barcode": "11010100004",
			"hot_level": "2"
		},
		{
			"id": "37",
			"name": "晨风的网吧",
			"barcode": "11010100001",
			"hot_level": "2"
		},
		{
			"id": "118",
			"name": "测试数据30",
			"barcode": "11010100047",
			"hot_level": "2"
		}
	],
	"total_num": 10
}
```
