# 自动发布脚本

## dependences.sh

安装发布需要的依赖

## build.sh

markdown 文件编译成 html 文件，并存储到 `_book` 目录

## deploy.sh

把 markdown 文件和编译好的 html 文件上传到 ftp
